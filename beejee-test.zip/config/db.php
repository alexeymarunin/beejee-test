<?php

/**
 * Настройки БД
 */

return [
    // Полный путь к файлу SQLite
    'path' => BEEJEE_ROOT . env( 'DB_PATH' ),
];
