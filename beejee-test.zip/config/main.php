<?php

return [
    'name'   => 'BeeJee test app',
    'db'     => require 'db.php',
    'routes' => require 'routes.php',
    'library' => require 'library.php',
];