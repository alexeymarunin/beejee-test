<?php

namespace app\models;

use app\base\Model;


/**
 * Класс Task
 *
 * @package app\models
 */
class Task extends Model
{
    /**
     * @var string
     */
    public $content;

    /**
     * @var string
     */
    public $username;

    /**
     * @var string
     */
    public $email;

    /**
     * @var int
     */
    public $media_id = 1;

    /**
     * @var int
     */
    public $status = 0;


    /**
     * @inheritdoc
     */
    public function getAttributes()
    {
        return [ 'id', 'content', 'username', 'email', 'media_id', 'status' ];
    }

    /**
     * @return string
     */
    public function getImageUrl()
    {
        /** @var Media $media */
        $media = $this->getDb()->media()->where( 'id', $this->media_id )->fetch();
        $url = env( 'UPLOADS_WEB_DIR' ) . ( $media ? $media->filename : '/noimage.png' );

        return $url;
    }

    /**
     * @inheritdoc
     */
    public function validate()
    {
        $this->clearErrors();

        if ( !$this->username ) {
            $this->addError( 'username', 'Введите имя пользователя' );
        }
        if ( !$this->email ) {
            $this->addError( 'email', 'Введите email' );
        }
        else {
            $validator = new \EmailValidator\Validator();
            if ( !$validator->isValid( $this->email ) ) {
                $this->addError( 'email', 'Неверный формат email' );
            }
        }
        if ( !$this->content ) {
            $this->addError( 'content', 'Введите описание задачи' );
        }

        return !$this->hasErrors();
    }

    /**
     * @return string
     */
    public static function tableName()
    {
        return 'tasks';
    }
}
